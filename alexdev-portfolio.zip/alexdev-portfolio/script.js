const translations = {
  en: {
    navAbout:"About",navProjects:"Projects",navApproach:"Approach",navContact:"Contact",
    status:"Building and learning in public",hello:"HELLO, WORLD. I'M",role:"Aspiring Software Developer",
    heroText:"I build practical digital projects, explore modern web technologies, and turn ideas into working experiences — one step at a time.",
    seeProjects:"Explore my projects",metaOne:"Curiosity first",metaTwo:"Build by doing",metaThree:"Always improving",
    chipBuild:"Build",chipCreate:"Create",online:"Open to learning opportunities",
    aboutEyebrow:"A LITTLE ABOUT ME",aboutTitle:"Ideas become better when we build.",
    aboutLead:"I'm an aspiring developer focused on learning through hands-on projects. I enjoy exploring how technology can solve everyday problems and creating digital products that are clear, useful, and accessible.",
    aboutNote:"This portfolio is a living work in progress. I'm documenting what I build, improving my skills, and being transparent about each project's stage.",
    projectsEyebrow:"SELECTED WORK",projectsTitle:"Projects in progress.",typeAI:"AI / INTERACTIVE SYSTEM",typeWeb:"WEB DEVELOPMENT",
    inProgress:"In development",jarvisDesc:"An AI assistant concept focused on voice and text interaction, useful tools, and a unified digital workspace. Currently being developed and tested.",
    caseStudySoon:"Case study coming as development progresses",calofaoDesc:"A web project being shaped into a useful online product, with an evolving interface and dashboard experience.",
    visitProject:"Visit project ↗",projectDisclaimer:"Project descriptions reflect their current stage. More details, demos, and source code will be added when they are ready to share.",
    approachEyebrow:"HOW I WORK",approachTitle:"Small steps. Real progress.",stepOneTitle:"Understand",stepOneText:"Start with the problem, the people, and the outcome that matters.",
    stepTwoTitle:"Build",stepTwoText:"Turn the idea into a clear, usable first version and test it.",stepThreeTitle:"Improve",stepThreeText:"Learn from feedback, fix issues, and keep making the product better.",
    contactEyebrow:"LET'S CONNECT",contactTitle:"Good things start with a conversation.",contactText:"Interested in following my work or sharing an opportunity? Find me on GitHub.",
    footer:"Designed and built with curiosity.",backTop:"Back to top ↑"
  },
  pt: {
    navAbout:"Sobre",navProjects:"Projetos",navApproach:"Como trabalho",navContact:"Contato",
    status:"Construindo e aprendendo em público",hello:"OLÁ, MUNDO. EU SOU",role:"Desenvolvedor de Software em formação",
    heroText:"Crio projetos digitais práticos, exploro tecnologias web modernas e transformo ideias em experiências funcionais — um passo de cada vez.",
    seeProjects:"Conheça meus projetos",metaOne:"Curiosidade em primeiro lugar",metaTwo:"Aprender fazendo",metaThree:"Sempre evoluindo",
    chipBuild:"Construir",chipCreate:"Criar",online:"Aberto a oportunidades de aprendizado",
    aboutEyebrow:"UM POUCO SOBRE MIM",aboutTitle:"As ideias melhoram quando colocamos a mão na massa.",
    aboutLead:"Sou um desenvolvedor em formação, focado em aprender por meio de projetos práticos. Gosto de explorar como a tecnologia pode resolver problemas do dia a dia e de criar produtos digitais claros, úteis e acessíveis.",
    aboutNote:"Este portfólio está em evolução. Estou documentando o que construo, desenvolvendo minhas habilidades e mostrando com transparência a etapa atual de cada projeto.",
    projectsEyebrow:"TRABALHOS SELECIONADOS",projectsTitle:"Projetos em andamento.",typeAI:"IA / SISTEMA INTERATIVO",typeWeb:"DESENVOLVIMENTO WEB",
    inProgress:"Em desenvolvimento",jarvisDesc:"Conceito de assistente de IA com foco em interação por voz e texto, ferramentas úteis e um espaço de trabalho digital unificado. Atualmente em desenvolvimento e testes.",
    caseStudySoon:"Estudo de caso será adicionado conforme o projeto evoluir",calofaoDesc:"Projeto web sendo desenvolvido como um produto digital útil, com interface e experiência de painel em evolução.",
    visitProject:"Visitar projeto ↗",projectDisclaimer:"As descrições refletem a etapa atual de cada projeto. Mais detalhes, demonstrações e código-fonte serão adicionados quando estiverem prontos para divulgação.",
    approachEyebrow:"COMO EU TRABALHO",approachTitle:"Pequenos passos. Progresso real.",stepOneTitle:"Entender",stepOneText:"Começar pelo problema, pelas pessoas e pelo resultado que importa.",
    stepTwoTitle:"Construir",stepTwoText:"Transformar a ideia em uma primeira versão clara, utilizável e testável.",stepThreeTitle:"Melhorar",stepThreeText:"Aprender com o feedback, corrigir problemas e evoluir o produto.",
    contactEyebrow:"VAMOS NOS CONECTAR",contactTitle:"Boas oportunidades começam com uma conversa.",contactText:"Quer acompanhar meu trabalho ou compartilhar uma oportunidade? Encontre-me no GitHub.",
    footer:"Criado com curiosidade e vontade de aprender.",backTop:"Voltar ao topo ↑"
  }
};
let currentLanguage = "en";
const languageToggle = document.getElementById("languageToggle");
function setLanguage(language) {
  currentLanguage = language;
  document.documentElement.lang = language === "pt" ? "pt-BR" : "en";
  document.querySelectorAll("[data-i18n]").forEach((element) => {
    const key = element.dataset.i18n;
    if (translations[language][key]) element.textContent = translations[language][key];
  });
  languageToggle.textContent = language === "en" ? "PT" : "EN";
  languageToggle.setAttribute("aria-label", language === "en" ? "Mudar para português" : "Switch to English");
}
languageToggle.addEventListener("click", () => setLanguage(currentLanguage === "en" ? "pt" : "en"));
const menuToggle = document.getElementById("menuToggle");
const mobileNav = document.getElementById("mobileNav");
menuToggle.addEventListener("click", () => {
  const isOpen = mobileNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
});
mobileNav.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => {
  mobileNav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));
document.getElementById("year").textContent = new Date().getFullYear();
