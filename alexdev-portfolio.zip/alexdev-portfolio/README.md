# Alex Dev — Portfolio

A responsive, bilingual (English/Portuguese) personal developer portfolio.

## Run locally
Open `index.html` in a browser. No build step or package installation is required.

## Files
- `index.html` — page structure and content
- `style.css` — responsive visual design
- `script.js` — language switcher, mobile navigation, and current year

## Customize before publishing
1. Confirm the GitHub profile URL in `index.html` and `script.js` is yours.
2. Add a professional contact method when you are ready.
3. Replace or expand project descriptions as each project becomes demonstrable.
4. Add screenshots and source-code links only when they are ready to share.

## Publish with GitHub Pages
1. Open repository **Settings → Pages**.
2. Under **Build and deployment**, choose **Deploy from a branch**.
3. Select branch `main` and folder `/ (root)`, then save.
4. Wait for GitHub Pages to publish the site.

Project status is intentionally described as “in development”; no unverified job experience or technical credentials are claimed.
